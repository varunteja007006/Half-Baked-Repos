export const patterns = {
	email: /^[\w-.]+@([\w-]+\.)+[\w-]{2,4}$/,
};
