import { UsersProvider } from './users/components/UsersProvider';

export function App() {
	return <UsersProvider />;
}
